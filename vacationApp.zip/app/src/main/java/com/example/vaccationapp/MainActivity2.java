package com.example.vaccationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView wel,vacation;
    private static int Splach_timeout=5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        wel=findViewById(R.id.textview1);
        vacation=findViewById(R.id.textview2);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent splachintent=new Intent(MainActivity2.this,Login.class);
            startActivity(splachintent);
            finish();
            }
        },Splach_timeout);

        Animation myanimation= AnimationUtils.loadAnimation(MainActivity2.this,R.anim.animation2);
        wel.startAnimation(myanimation);
        Animation myanimation2= AnimationUtils.loadAnimation(MainActivity2.this,R.anim.animation1);
        vacation.startAnimation(myanimation2);
    }
}