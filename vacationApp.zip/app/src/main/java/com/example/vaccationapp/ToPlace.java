package com.example.vaccationapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;


import com.example.vaccationapp.adapter.TopPlacesAdapter;

import com.example.vaccationapp.model.TopPlacesData;

import java.util.ArrayList;
import java.util.List;

public class ToPlace extends AppCompatActivity {

    RecyclerView topPlacesRecycler;
    TopPlacesAdapter topPlacesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);


        List<TopPlacesData> topPlacesDataList = new ArrayList<>();
        topPlacesDataList.add(new TopPlacesData("Berlin","Allemagne","2000dt",R.drawable.berlin));
        topPlacesDataList.add(new TopPlacesData("Venise","Italie","2700dt",R.drawable.italie));
        topPlacesDataList.add(new TopPlacesData("Gèneve","Suisse","3000dt",R.drawable.suisse));
        topPlacesDataList.add(new TopPlacesData("Nil","Egypte","2500dt",R.drawable.nil));
        topPlacesDataList.add(new TopPlacesData("Antalya","Turquie","3000dt",R.drawable.anta));

        setTopPlacesRecycler(topPlacesDataList);

    }

    private  void setTopPlacesRecycler(List<TopPlacesData> topPlacesDataList){

        topPlacesRecycler = findViewById(R.id.top_places_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        topPlacesRecycler.setLayoutManager(layoutManager);
        topPlacesAdapter = new TopPlacesAdapter(this, topPlacesDataList);
        topPlacesRecycler.setAdapter(topPlacesAdapter);

    }




    public void Home(View view){
        Intent intent = new Intent(ToPlace.this,MainActivity.class);
        startActivity(intent);
    }

    public void Profile(View view){
        Intent intent = new Intent(ToPlace.this,Profile.class);
        startActivity(intent);
    }


    public void Hotel(View view){
        Intent intent = new Intent(ToPlace.this, ToPlace.class);
        startActivity(intent);
    }

    public void Map(View view){
        Intent intent = new Intent(ToPlace.this,Map.class);
        startActivity(intent);
    }
}