package com.example.vaccationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.example.vaccationapp.adapter.RecentsAdapter;

import com.example.vaccationapp.model.RecentsData;
import com.google.firebase.database.core.Context;


import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity  {

    private RecyclerView recentRecycler;
    private RecentsAdapter recentsAdapter;
    private List<RecentsData> recentsDataList = new ArrayList<>();
    private SearchView search_bar;

    ImageView popupBtn;
    Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        popupBtn=findViewById(R.id.im1);
        mDialog=new Dialog(this);

        popupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDialog.setContentView(R.layout.activity_pop_up);
                mDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                Intent intent = new Intent(MainActivity.this,PopUp.class);
                startActivity(intent);

            }
        });


        search_bar=(SearchView)findViewById(R.id.search_bar);
        recentRecycler=(RecyclerView)findViewById(R.id.recent_recycler);


        // Now here we will add some dummy data in our model class

        List<RecentsData> recentsDataList = new ArrayList<>();
        recentsDataList.add(new RecentsData(" Montreal","Canada","From 4000dt", R.drawable.canda));
        recentsDataList.add(new RecentsData("Instanbul","Turquie","From 1300dt",R.drawable.turquie));
        recentsDataList.add(new RecentsData("Tour","Dubai","From 4000dt",R.drawable.dubai));
        recentsDataList.add(new RecentsData("Ubud","Bali","From 5000dt", R.drawable.balii));
        recentsDataList.add(new RecentsData("Santorini","Younane","From 2000dt",R.drawable.younane));
        recentsDataList.add(new RecentsData("Paris","France","From 2500dt",R.drawable.paris));

        setRecentRecycler(recentsDataList);

    }



    private  void setRecentRecycler(List<RecentsData> recentsDataList){

        recentRecycler = findViewById(R.id.recent_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        recentRecycler.setLayoutManager(layoutManager);
        recentsAdapter = new RecentsAdapter(this, recentsDataList);
        recentRecycler.setAdapter(recentsAdapter);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuoptiion,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.quit:
                finish();
                return true;
            case R.id.lange:
                Intent i=new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(i);
                return true;
            case R.id.date:
                Intent ii=new Intent(Settings.ACTION_DATE_SETTINGS);
                startActivity(ii);
                return true;

            default:     return super.onOptionsItemSelected(item);
        }
    }



    public void Home(View view){
        Intent intent = new Intent(MainActivity.this,MainActivity.class);
        startActivity(intent);
    }

    public void Profile(View view){
        Intent intent = new Intent(MainActivity.this,Profile.class);
        startActivity(intent);
    }


    public void Hotel(View view){
        Intent intent = new Intent(MainActivity.this, ToPlace.class);
        startActivity(intent);
    }

    public void Map(View view){
        Intent intent = new Intent(MainActivity.this,Map.class);
        startActivity(intent);
    }




}