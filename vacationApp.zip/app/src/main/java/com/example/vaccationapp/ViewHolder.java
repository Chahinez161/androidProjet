package com.example.vaccationapp;

import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vaccationapp.model.RecentsData;

public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView nom;
        public TextView country;
        public TextView price;
        public ImageView img;



        public ViewHolder(View itemView) {
            super(itemView);
            nom=(TextView)itemView.findViewById(R.id.place_name);
            country=(TextView)itemView.findViewById(R.id.country_name);
            price=(TextView)itemView.findViewById(R.id.price);
            img=(ImageView)itemView.findViewById(R.id.place_image);


        }

        public void bind(RecentsData recentsData){
            nom.setText(recentsData.getPlaceName() );
            country.setText(recentsData.getCountryName() );
            price.setText(recentsData.getPrice() );

        }

        @Override
        public void onClick(View v) {

        }
}