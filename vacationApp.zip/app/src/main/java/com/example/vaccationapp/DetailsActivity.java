package com.example.vaccationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class DetailsActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);




    }

    public void fleche(View view){
        Intent intent = new Intent(DetailsActivity.this,MainActivity.class);
        startActivity(intent);
    }

    public void reservation(View view){
        Intent intent = new Intent(DetailsActivity.this,Reservation.class);
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuoptiion,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.quit:
                finish();
                return true;
            case R.id.lange:
                Intent i=new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(i);
                return true;
            case R.id.date:
                Intent ii=new Intent(Settings.ACTION_DATE_SETTINGS);
                startActivity(ii);
                return true;

            default:     return super.onOptionsItemSelected(item);
        }
    }
}
