package com.example.vaccationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.view.View;

public class Profile extends AppCompatActivity {

    TextView b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        b1=findViewById(R.id.label);
        b2=findViewById(R.id.label1);
        b3 = findViewById(R.id.label3);
        b4 = findViewById(R.id.label4);

        registerForContextMenu(b1);
        registerForContextMenu(b2);
        registerForContextMenu(b3);
        registerForContextMenu(b4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gmail.com"));
                startActivity(j);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com"));
                startActivity(j);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Chahinez161"));
                startActivity(j);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"));
                startActivity(j);
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.pink:
                b1.setTextColor(getResources().getColor(R.color.rose));
                return true;
            case R.id.yallow:
                b1.setTextColor(getResources().getColor(R.color.jaune));
                return true;
            case R.id.mauvve:
                b1.setTextColor(getResources().getColor(R.color.mauve));
                return true;



            case R.id.ppink:
                b2.setTextColor(getResources().getColor(R.color.rose));
                return true;
            case R.id.yalloow:
                b2.setTextColor(getResources().getColor(R.color.jaune));
                return true;
            case R.id.mauuvve:
                b2.setTextColor(getResources().getColor(R.color.mauve));
                return true;


            case R.id.piink:
                b3.setTextColor(getResources().getColor(R.color.rose));
                return true;
            case R.id.yalloww:
                b3.setTextColor(getResources().getColor(R.color.jaune));
                return true;
            case R.id.mauvvve:
                b3.setTextColor(getResources().getColor(R.color.mauve));
                return true;


            case R.id.pinnk:
                b4.setTextColor(getResources().getColor(R.color.rose));
                return true;
            case R.id.yaallow:
                b4.setTextColor(getResources().getColor(R.color.jaune));
                return true;
            case R.id.mmauvve:
                b4.setTextColor(getResources().getColor(R.color.mauve));
                return true;


            default:
                return super.onContextItemSelected(item);}
    }




    public void Home(View view){
        Intent intent = new Intent(Profile.this,MainActivity.class);
        startActivity(intent);
    }

    public void Profile(View view){
        Intent intent = new Intent(Profile.this,Profile.class);
        startActivity(intent);
    }


    public void Hotel(View view){
        Intent intent = new Intent(Profile.this, ToPlace.class);
        startActivity(intent);
    }

    public void Map(View view){
        Intent intent = new Intent(Profile.this,Map.class);
        startActivity(intent);
    }
}